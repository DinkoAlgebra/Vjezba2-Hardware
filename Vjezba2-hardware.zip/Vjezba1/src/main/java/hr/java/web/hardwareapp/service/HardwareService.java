package hr.java.web.hardwareapp.service;

import hr.java.web.hardwareapp.dto.HardwareDTO;

import java.util.List;

public interface HardwareService {

    List<HardwareDTO> findAll();

    HardwareDTO findByCode(String code);

}
