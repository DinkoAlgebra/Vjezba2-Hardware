package hr.java.web.hardwareapp.controller;

import hr.java.web.hardwareapp.service.HardwareService;
import hr.java.web.hardwareapp.dto.HardwareDTO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("hardware")
public class HardwareController {

    private final HardwareService hardwareService;

    public HardwareController(HardwareService hardwareService) {
        this.hardwareService = hardwareService;
    }

    @GetMapping
    public List<HardwareDTO> getAll() {
        return hardwareService.findAll();
    }

    @GetMapping(params = "code")
    public HardwareDTO getByCode(@RequestParam final String code) {
        return hardwareService.findByCode(code);
    }

}
